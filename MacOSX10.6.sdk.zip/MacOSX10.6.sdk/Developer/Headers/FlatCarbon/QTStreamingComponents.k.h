#include <QuickTime/QTStreamingComponents.k.h>
