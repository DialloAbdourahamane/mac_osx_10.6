/* CommResources.r is not available on Mac OS X */
