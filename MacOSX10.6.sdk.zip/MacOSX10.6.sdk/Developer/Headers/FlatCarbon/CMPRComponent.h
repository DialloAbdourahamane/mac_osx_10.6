#warning CMPRComponent.h is not available on Mac OS X
