#warning ENET.h is not available on Mac OS X
