#warning CMConversions.h is not available on Mac OS X
