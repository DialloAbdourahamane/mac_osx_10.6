/* OpenTransportKernel.r is not available on Mac OS X */
