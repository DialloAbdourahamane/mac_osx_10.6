#warning CommResources.h is not available on Mac OS X
